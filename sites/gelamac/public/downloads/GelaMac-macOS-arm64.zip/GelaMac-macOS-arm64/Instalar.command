#!/bin/zsh
set -euo pipefail

package_dir="${0:A:h}"
source_app="$package_dir/GelaMac.app"
destination='/Applications/GelaMac.app'

if [[ "$(uname -m)" != 'arm64' ]]; then
    print -u2 'Esta prévia é para Apple Silicon. A versão Intel ainda não está disponível.'
    exit 1
fi
os_major="$(sw_vers -productVersion | cut -d. -f1)"
if (( os_major < 14 )); then
    print -u2 'O GelaMac requer macOS 14 ou posterior.'
    exit 1
fi
if [[ ! -d "$source_app" ]]; then
    print -u2 'Mantenha Instalar.command na mesma pasta de GelaMac.app.'
    exit 1
fi
if pgrep -x GelaMac >/dev/null; then
    print -u2 'Encerre o GelaMac pelo botão de desligar antes de instalar ou atualizar.'
    exit 1
fi
codesign --verify --deep --strict "$source_app"
if [[ ! -w /Applications ]]; then
    print -u2 'Seu usuário não pode gravar em Aplicativos. Peça a um administrador para instalar o app nessa pasta pelo Finder.'
    exit 1
fi

staging="$(mktemp -d /Applications/.GelaMac-install.XXXXXX)"
previous=''
cleanup() {
    if [[ ! -e "$destination" && -n "$previous" && -e "$previous" ]]; then
        mv "$previous" "$destination"
    fi
    rmdir "$staging" 2>/dev/null || true
}
trap cleanup EXIT
ditto "$source_app" "$staging/GelaMac.app"
codesign --verify --deep --strict "$staging/GelaMac.app"
if [[ -e "$destination" ]]; then
    installed_build="$(/usr/libexec/PlistBuddy -c 'Print CFBundleVersion' "$destination/Contents/Info.plist" 2>/dev/null || print 0)"
    if (( installed_build >= 10 )) && [[ -f "$destination/Contents/Library/LaunchDaemons/com.gelamac.fanservice.plist" ]]; then
        "$destination/Contents/MacOS/GelaMac" --prepare-update
    fi
    backup_dir="$HOME/Library/Application Support/GelaMac/Previous Versions"
    mkdir -p "$backup_dir"
    previous="$backup_dir/GelaMac-$(uuidgen).app"
    mv "$destination" "$previous"
fi
mv "$staging/GelaMac.app" "$destination"
registry='/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister'
"$registry" -f "$destination"
mdimport "$destination"
print 'GelaMac instalado em /Applications/GelaMac.app.'
print 'A primeira abertura pode exigir permissão em Ajustes do Sistema > Privacidade e Segurança.'
print 'Depois, aprove o auxiliar de controle de ventoinhas quando o macOS solicitar.'
print 'A senha não é armazenada. O instalador não desativa o Gatekeeper nem remove a quarentena.'
open "$destination"
